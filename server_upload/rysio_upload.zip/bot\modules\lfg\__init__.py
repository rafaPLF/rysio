"""LFG module."""
