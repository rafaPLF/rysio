"""Premium module."""
