"""Discord bot package."""
