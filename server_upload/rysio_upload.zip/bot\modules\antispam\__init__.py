"""Anti-spam module."""
