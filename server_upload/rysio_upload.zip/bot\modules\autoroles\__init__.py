"""Autoroles module."""
