"""Core bot infrastructure."""
